# Beacon Wellbeing Trust Fabric Starter Project

This repository provides a Microsoft Fabric data engineering starter project for the Beacon Wellbeing Trust hackathon. It scaffolds a Medallion-style lakehouse with reusable PySpark helpers, starter notebooks, documentation, and a semantic model placeholder for rapid prototyping.

## Hackathon goals

- Ingest Beacon Wellbeing Trust datasets from Fabric landing-zone storage.
- Standardise native and parquet files into conformed silver datasets.
- Publish gold analytical tables for care delivery metrics, staffing utilisation, and facility activity.
- Seed a semantic model that can be extended and published to Power BI.

## Repository structure

- `/bronze` - ingestion notebooks for CSV, JSON, and parquet files from `abfss` storage.
- `/silver` - cleansing and standardisation notebooks using PySpark.
- `/gold` - modelling notebook producing analytical tables for care delivery metrics.
- `/semantic-model` - starter semantic model JSON placeholder.
- `/utils` - Python helpers for schema inference, validation, logging, and common transformations.
- `/docs` - architecture overview, data flow diagrams, and Fabric run instructions.

## Source storage paths

- `abfss://landingzone@stdnalnzukdev01.dfs.core.windows.net/20260923-fi4-beaconwellbeingtrust-native`
- `abfss://landingzone@stdnalnzukdev01.dfs.core.windows.net/20260923-fi4-beaconwellbeingtrust-parquet`

## Running in Fabric

1. Import the `bronze`, `silver`, and `gold` notebooks into your Fabric workspace.
2. Attach a Lakehouse and make the `utils` package available to the notebooks.
3. Run the bronze notebooks to ingest raw data and review the built-in quality metrics.
4. Run the silver notebooks to standardise care delivery, staffing, and facility activity datasets.
5. Run the gold notebook to produce analytical outputs and funding-alignment metrics.
6. Use the semantic model starter in `/semantic-model` to build a Fabric or Power BI semantic model.

Detailed setup guidance is available in `/docs/run-in-fabric.md`.

## Extending the starter

- Add new ingestion notebooks under `/bronze` for additional source folders or formats.
- Reuse and extend the helper modules in `/utils` for shared quality and transformation rules.
- Expand the semantic model with new tables, relationships, and measures.
- Publish the resulting model to Power BI after validating the gold-layer outputs.
