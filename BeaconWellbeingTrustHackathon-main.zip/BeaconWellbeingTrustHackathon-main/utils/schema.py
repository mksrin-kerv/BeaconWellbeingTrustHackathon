from pyspark.sql import DataFrame


def read_native_with_schema_inference(spark, path: str, file_format: str, options: dict | None = None) -> DataFrame:
    """Read CSV or JSON data from Fabric lakehouse storage with schema inference enabled."""
    reader = spark.read.format(file_format).option("inferSchema", True)
    for key, value in (options or {}).items():
        reader = reader.option(key, value)
    return reader.load(path)


def read_parquet_dataset(spark, path: str) -> DataFrame:
    """Read parquet files from Fabric lakehouse storage."""
    return spark.read.format("parquet").load(path)
