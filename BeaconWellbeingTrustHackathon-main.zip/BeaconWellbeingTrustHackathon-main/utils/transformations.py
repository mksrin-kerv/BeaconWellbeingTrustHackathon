from pyspark.sql import DataFrame, functions as F


def rename_columns(df: DataFrame, rename_map: dict[str, str]) -> DataFrame:
    for source, target in rename_map.items():
        df = df.withColumnRenamed(source, target)
    return df


def normalise_text_columns(df: DataFrame, columns: list[str]) -> DataFrame:
    for column in columns:
        df = df.withColumn(column, F.trim(F.lower(F.col(column))))
    return df


def standardise_dates(df: DataFrame, columns: list[str], source_format: str = "yyyy-MM-dd") -> DataFrame:
    for column in columns:
        df = df.withColumn(column, F.to_date(F.col(column), source_format))
    return df
