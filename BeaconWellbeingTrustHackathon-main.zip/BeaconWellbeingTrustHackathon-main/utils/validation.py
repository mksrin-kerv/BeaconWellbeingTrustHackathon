from pyspark.sql import DataFrame, functions as F


def run_data_quality_checks(
    df: DataFrame,
    business_key_columns: list[str],
    expected_dtypes: dict[str, str] | None = None,
) -> dict[str, int]:
    """Return simple data quality metrics for nulls, inferred-schema mismatches, and duplicate rows."""
    null_metrics = df.agg(*[
        F.sum(F.when(F.col(column).isNull(), 1).otherwise(0)).alias(column)
        for column in df.columns
    ]).collect()[0].asDict()
    null_count = sum(null_metrics.values())
    actual_dtypes = dict(df.dtypes)
    type_mismatch_count = sum(
        1
        for column, expected_dtype in (expected_dtypes or {}).items()
        if actual_dtypes.get(column) != expected_dtype
    )
    duplicate_count = 0
    if business_key_columns:
        duplicate_count_row = (
            df.groupBy(*business_key_columns)
            .count()
            .filter(F.col("count") > 1)
            .agg(F.sum(F.col("count") - 1).alias("duplicate_rows"))
            .collect()[0]["duplicate_rows"]
        )
        duplicate_count = int(duplicate_count_row or 0)
    return {
        "null_count": null_count,
        "type_mismatch_count": type_mismatch_count,
        "duplicate_count": duplicate_count,
    }
