# Data flow diagrams

## Dataset examples

```mermaid
flowchart TD
    CD[Care delivery CSV] --> B1[Bronze care_delivery_csv]
    SA[Staffing JSON] --> B2[Bronze staffing_json]
    FA[Facility parquet] --> B3[Bronze facility_activity_parquet]
    B1 --> S1[Silver care_delivery]
    B2 --> S2[Silver staff_activity]
    B3 --> S3[Silver facility_activity]
    S1 --> G1[Gold care_episodes]
    S2 --> G2[Gold staff_activity]
    S3 --> G3[Gold facility_utilisation]
    G1 --> G4[Gold funding_alignment]
    G2 --> G4
    G1 --> D1[Gold dim_region]
    G2 --> D1
    G3 --> D2[Gold dim_calendar]
    G4 --> D1
    G4 --> D2
```

## Quality controls

- Null detection is performed across all bronze ingestions.
- Type mismatch checks compare inferred post-read Spark column types with the starter project's expected column types for each dataset.
- Duplicate detection is based on supplied business keys using raw bronze column names and conformed silver names where appropriate.
