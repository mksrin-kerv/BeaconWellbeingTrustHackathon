# Architecture overview

Beacon Wellbeing Trust's hackathon starter project follows a Microsoft Fabric Medallion pattern:

- **Bronze** notebooks ingest CSV, JSON, and parquet datasets from the Fabric landing zone using `abfss://` URIs.
- **Silver** notebooks standardise care delivery, staffing, and facility activity datasets with reusable PySpark helpers.
- **Gold** notebooks publish analytical tables for care delivery metrics and funding alignment.
- **Semantic model** assets provide a starter structure for Power BI and Fabric semantic modelling.

```mermaid
flowchart LR
    A[Landing zone
Native + parquet files] --> B[Bronze notebooks]
    B --> C[Silver notebooks]
    C --> D[Gold analytical tables]
    D --> E[Fabric semantic model / Power BI]
```
