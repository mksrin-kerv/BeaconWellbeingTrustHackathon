# Run in Microsoft Fabric

1. Create or open a Fabric workspace with a Lakehouse attached.
2. Upload the `utils` folder as workspace files or package it as a notebook dependency.
3. Import the notebooks from `bronze`, `silver`, and `gold` into Fabric.
4. Update table names or save commands so bronze outputs land in your target Lakehouse.
5. Run bronze notebooks in sequence:
   - `01_ingest_csv.ipynb`
   - `02_ingest_json.ipynb`
   - `03_ingest_parquet.ipynb`
6. Persist bronze outputs, then run silver notebooks to create `silver.care_delivery`, `silver.staff_activity`, and `silver.facility_activity`.
7. Run `gold/01_build_care_delivery_metrics.ipynb` to generate analytical tables.
8. Import `semantic-model/beacon-semantic-model.json` into a Fabric semantic model project or use it as a mapping reference for Power BI.

## Extending the project

- Add new source-specific notebooks in `bronze` for additional landing zone folders.
- Extend `utils/transformations.py` with reusable conformance rules.
- Add new analytical tables and DAX measures as more care delivery KPIs are defined.
- Publish gold tables to Power BI by connecting the semantic model to the Lakehouse or Warehouse endpoint.
